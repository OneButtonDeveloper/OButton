﻿// ==UserScript==
// @name one-button
// @include http://*
// @include https://*
// @include about:blank
// @require libs/jquery-2.1.4.min.js
// @require libs/handlebars.min-latest.js
// ==/UserScript==

var $ = window.$.noConflict(true); // Required for IE

// console.log('Main.js: JQuery ' + $.fn.jquery  + ' Handlebars: ' + Handlebars.VERSION);